import {Component} from "@angular/core";


@Component({
    selector:"daimler-app",
    templateUrl:"./app/app.component.html",
    styleUrls:["./app/app.component.css"]
})
export class AppComponent
{

    private logo:String
    private banner:String;

    constructor()
    {
        this.logo="./app/images/daimlerlogo.jpg";
        this.banner="./app/images/daimlerbanner.jpg"
    }


}