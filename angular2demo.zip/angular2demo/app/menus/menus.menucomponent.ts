import {Component, OnInit} from "@angular/core";
import {MenuService} from "../service/service.menuService";
import {Menu} from "../model/model.menu";


@Component({
    selector:"daimler-menu",
    templateUrl:"./app/menus/menus.menucomponent.html",
    styleUrls:["./app/menus/menus.menucomponent.css"]
})
export class MenuComponent implements OnInit
{

     private menuArray:any=[];
    constructor(private menuService:MenuService)
    {


    }

    ngOnInit()
    {

        this.menuService.getData().then(response=>{
            response.forEach(obj=>{
                this.menuArray.push(obj);
            })
        })


    }


}