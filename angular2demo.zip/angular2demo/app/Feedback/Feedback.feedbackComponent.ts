import {Component} from "@angular/core";


@Component({
    templateUrl:'./app/Feedback/Feedback.feedbackComponent.html',
    styleUrls:['./app/Feedback/Feedback.feedbackComponent.css']
})
export class FeedbackComponent
{



}