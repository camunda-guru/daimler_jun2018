import {Menu} from "./model.menu";


export const MenuCollection:Menu[]=[new Menu(1,"Services"),
    new Menu(2,"Work"),
    new Menu(3,"Training and Development"),
    new Menu(4,"About us"),
    new Menu(5,"Feedback")

]