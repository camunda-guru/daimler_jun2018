import {Injectable} from "@angular/core";
import {Menu} from "../model/model.menu";
import {MenuCollection} from "../model/model.menuCollection";


@Injectable()
export class MenuService
{

    getData():Promise<Menu[]>
    {
        return Promise.resolve(MenuCollection);
    }
}