import {NgModule} from "@angular/core";
import {AppComponent} from "./app.component";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {MenuComponent} from "./menus/menus.menucomponent";
import {MenuService} from "./service/service.menuService";
import {DaimlerServiceComponent} from "./DaimlerService/DaimlerService.serviceComponent";
import {AppRoutingModule} from "./app.routingmodule";
import {WorkComponent} from "./Work/Work.workComponent";
import {TrainingComponent} from "./Training/Training.trainingComponent";
import {FeedbackComponent} from "./Feedback/Feedback.feedbackComponent";


@NgModule({
    imports:[BrowserModule,CommonModule,AppRoutingModule],
    declarations:[AppComponent,MenuComponent,DaimlerServiceComponent,WorkComponent,TrainingComponent,FeedbackComponent],
    providers:[MenuService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}