import {NgModule} from "@angular/core";
import {AppComponent} from "./app.component";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {MenuComponent} from "./menus/menus.menucomponent";
import {MenuService} from "./service/service.menuService";


@NgModule({
    imports:[BrowserModule,CommonModule],
    declarations:[AppComponent,MenuComponent],
    providers:[MenuService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}