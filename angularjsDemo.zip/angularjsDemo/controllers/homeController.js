homeApp.controller('HomeController',
    ['$scope','$location',function($scope,$location)
{
   //model for user
    $scope.userObj={
        userName:'',
        password:''
    }

    $scope.save=function()
    {
        console.log($scope.userObj);
        if(($scope.userObj.userName=="admin")&&($scope.userObj.password=="admin123"))
        {
            console.log("login successful");
            $location.path('/login');
        }

    }


}])