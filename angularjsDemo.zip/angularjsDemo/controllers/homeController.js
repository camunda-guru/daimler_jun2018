homeApp.controller('HomeController',
    ['$scope',function($scope)
{
   //model for user
    $scope.userObj={
        userName:'',
        password:''
    }


}])