homeApp.controller('ProductController',['$scope','AlbumService',
    function($scope,AlbumService)
{

    AlbumService.albumObj().then(function(response)
    {
       console.log(response);
        $scope.albums=response.data;
    })


}])