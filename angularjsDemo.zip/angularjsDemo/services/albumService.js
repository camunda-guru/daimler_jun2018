homeApp.service('AlbumService',['$http',function($http)
{

    var albumList=function()
    {
        return $http({
            url:"https://jsonplaceholder.typicode.com/albums",
            method:"GET",
            dataType:"jsonp",
            headers:{
                'Content-Type': 'application/json'
            }
        })
    }
    //singleton object in js
    return{
        albumObj:albumList
    }




}]);