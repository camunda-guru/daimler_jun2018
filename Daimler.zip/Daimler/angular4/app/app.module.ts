import {NgModule} from "@angular/core";
import {AppComponent} from "./app.component";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {MenuComponent} from "./menus/menus.menucomponent";
import {MenuService} from "./service/service.menuService";
import {DaimlerServiceComponent} from "./DaimlerService/DaimlerService.serviceComponent";
import {AppRoutingModule} from "./app.routingmodule";
import {WorkComponent} from "./Work/Work.workComponent";
import {TrainingComponent} from "./Training/Training.trainingComponent";
import {FeedbackComponent, ShowDialog} from "./Feedback/Feedback.feedbackComponent";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {MatButtonModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatDialogModule}
from "@angular/material";
import { HttpModule, JsonpModule } from "@angular/http";
import {EqualValidator} from "./Feedback/matchvalidator";
import {CountryService} from "./service/service.countryservice";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {FeedbackService} from "./service/service.feedbackService";

@NgModule({
    imports:[BrowserModule,CommonModule,AppRoutingModule,
        ReactiveFormsModule,HttpModule,FormsModule,JsonpModule,MatButtonModule,
        MatFormFieldModule,MatInputModule,MatSelectModule,MatDialogModule,BrowserAnimationsModule],
    declarations:[AppComponent,MenuComponent,DaimlerServiceComponent,WorkComponent,
        TrainingComponent,FeedbackComponent,EqualValidator,ShowDialog],
    entryComponents: [ShowDialog],
    providers:[MenuService,CountryService,FeedbackService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}