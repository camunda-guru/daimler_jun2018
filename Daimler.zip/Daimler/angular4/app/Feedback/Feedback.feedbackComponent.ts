import {Component, HostBinding,OnInit,Inject} from "@angular/core"
import { CountryService } from "../service/service.countryservice";
import {FormGroup,FormBuilder,Validators,FormControl} from "@angular/forms";
import {Observable} from 'rxjs';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {FeedbackService} from "../service/service.feedbackService";


@Component({
    templateUrl:'./app/Feedback/Feedback.feedbackComponent.html',
    styleUrls:['./app/Feedback/Feedback.feedbackComponent.css']
})
export class FeedbackComponent implements OnInit
{
private  selected:string = 'India';
private feedbackForm:FormGroup;
private name:FormControl;
private countryName:FormControl;
private password:FormControl;
private confirmPassword:FormControl;
private selectedCountry:string="India";
    errorMessage: String;
private countries:any=[];
constructor(private countryService:CountryService,private feedbackService:FeedbackService,
    private formBuilder:FormBuilder,private matDialog:MatDialog)
{

    this.name=new FormControl('',[Validators.minLength(5),
        Validators.maxLength(25),Validators.required,
        Validators.pattern('[A-Za-z]{5,25}')]);

    this.password=new FormControl('',[Validators.required]);
    this.confirmPassword=new FormControl('',[Validators.required]);
    this.countryName=new FormControl('',[Validators.required]);

    this.feedbackForm=formBuilder.group({
        name:this.name,
        password:this.password,
        confirmPassword:this.confirmPassword,
        countryName:this.countryName
    })

}

ngOnInit()
{
    this.countryService.getCountryNames().subscribe(response=>
    {
        //console.log(response);
        this.countries.push(response);
    });
}
OnSelection(value):void
    {
        console.log(value);
}
save():void
    {
        console.log(this.feedbackForm.value);
        this.feedbackService.submitFeedback(this.feedbackForm.value).then( res => {
                console.log(res);
            },
            error => this.errorMessage = <any>error);
let dialogRef = this.matDialog.open(ShowDialog, {
    width: '250px',
    data: {Name:this.feedbackForm.value.name,
        Country: this.feedbackForm.value.countryName,}
});
dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');

});

this.clearForm();
}
clearForm() {

    this.feedbackForm.reset({
        'name': '',
        'password': '',
        'confirmPassword': '',
        'countryName': ''

    });
}

public test()
{
    console.log("Invoking child component method..");
}

}

@Component({
    selector: 'show-dialog',
    templateUrl: './app/Feedback/show-dialog.html',
})
export class ShowDialog {

    constructor(
        public dialogRef: MatDialogRef<ShowDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}