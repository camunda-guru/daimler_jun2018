export class Menu
{
    private menuId:Number;
    private menuName:String;
    constructor(id:Number,mname:String)
    {
        this.menuId=id;
        this.menuName=mname;
    }

    get MenuId():Number
    {
        return this.menuId;
    }

    get MenuName():String
    {
        return this.menuName;
    }


}