homeApp.controller('HomeController',
    ['$scope','$location',function($scope,$location)
{
   //model for user
    $scope.userObj={
        userName:'',
        password:''
    }
    $scope.display=true;

    $scope.save=function()
    {
        console.log($scope.userObj);
        if(($scope.userObj.userName=="admin")&&($scope.userObj.password=="admin123"))
        {
            console.log("login successful");
            $scope.display=false;
            $location.path('/login');
        }

    }


}])