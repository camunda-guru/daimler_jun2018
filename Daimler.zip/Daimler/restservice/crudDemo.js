var mongoose = require('mongoose');
var FeedbackModel= require('./schemaDemo').FeedbackModel;
mongoose.connect('mongodb://localhost:27017/customerdb');

module.exports.Add=function(pname,ppassword,pconfirmPassword,pcountryName)
{
    console.log(pname);

    var db = mongoose.connection;
    db.once('open', function() {
    });

    var obj = new FeedbackModel(
        {
            name:pname,
            password:ppassword,
            confirmPassword:pconfirmPassword,
            countryName:pcountryName

        });
    obj.save(function(err,result){
        if(!err)
            console.log(result);

    });

}