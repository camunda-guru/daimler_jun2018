express=require("express");
cors=require("cors");
bodyParser=require("body-parser");
var refCrud = require("./crudDemo");

var app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.get('/welcome',function(request,response)
{

    response.send("Ready to use REST Service");
})

app.post('/feedback',function(req,res)
{
    console.log(req.body);
     refCrud.Add(req.body.name,req.body.password,
         req.body.confirmPassword,req.body.countryName.name);
    res.send({"Data":req.body.name+"received"});



})

app.listen(4300,function()
{
    console.log("Server running on http://localhost:4300");
})






