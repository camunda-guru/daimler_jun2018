var mongoose = require('mongoose');
Schema = mongoose.Schema;

var feedbackSchema = new mongoose.Schema({
    name: String,
    password:String,
    confirmPassword:String,
    countryName:String
})

module.exports.FeedbackModel = mongoose.model('FeedbackModel',feedbackSchema);