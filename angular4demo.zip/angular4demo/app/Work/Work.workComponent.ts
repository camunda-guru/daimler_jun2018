import {Component} from "@angular/core";

@Component({
    templateUrl:'./app/Work/Work.workComponent.html',
    styleUrls:['./app/Work/Work.workComponent.css']
})
export class WorkComponent
{

}