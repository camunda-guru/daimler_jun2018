import {Component} from "@angular/core";

@Component({
    templateUrl:'./app/Training/Training.trainingComponent.html',
    styleUrls:['./app/Training/Training.trainingComponent.css']
})
export class TrainingComponent
{

}