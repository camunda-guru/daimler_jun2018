import {Component} from "@angular/core";

@Component({

    templateUrl:'./app/DaimlerService/DaimlerService.serviceComponent.html',
    styleUrls:['./app/DaimlerService/DaimlerService.serviceComponent.css']
})
export class DaimlerServiceComponent
{

}