import {NgModule} from "@angular/core";

import {DaimlerServiceComponent} from "./DaimlerService/DaimlerService.serviceComponent";
import {WorkComponent} from "./Work/Work.workComponent";
import {TrainingComponent} from "./Training/Training.trainingComponent";
import {FeedbackComponent} from "./Feedback/Feedback.feedbackComponent";
import {Routes,RouterModule} from "@angular/router";

const routes:Routes=[{
path:'Services',
component:DaimlerServiceComponent
},
    {
        path:'Work',
        component:WorkComponent
    },
    {
        path:'Training and Development',
        component:TrainingComponent
    },

    {
        path:'Feedback',
        component:FeedbackComponent
    }

    ]



@NgModule(
    {
     imports:[RouterModule.forRoot(routes)],
     exports:[RouterModule]

    }
)
export class AppRoutingModule
{

}